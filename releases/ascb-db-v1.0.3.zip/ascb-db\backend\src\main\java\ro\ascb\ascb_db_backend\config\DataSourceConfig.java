package ro.ascb.ascb_db_backend.config;

import java.sql.Connection;
import java.sql.SQLException;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.jdbc.DataSourceProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;

import com.zaxxer.hikari.HikariDataSource;

import jakarta.annotation.PreDestroy;

@Configuration
@EnableConfigurationProperties(DataSourceProperties.class)
public class DataSourceConfig {

    private static final Logger logger = LoggerFactory.getLogger(DataSourceConfig.class);
    private HikariDataSource delegate;

    @Bean
    @Primary
    public DataSource dataSource(DataSourceProperties properties) {
        DataSource productionDataSource = createDataSource(properties);
        if (isDataSourceHealthy(productionDataSource)) {
            logger.info("Using production datasource: {}", properties.determineUrl());
            return productionDataSource;
        }

        logger.warn("Production datasource unavailable. Falling back to embedded H2.");
        DataSourceProperties h2Properties = createH2Properties();
        DataSource h2DataSource = createDataSource(h2Properties);
        if (isDataSourceHealthy(h2DataSource)) {
            logger.info("Fallback datasource is ready: {}", h2Properties.determineUrl());
            return h2DataSource;
        }

        throw new IllegalStateException("Unable to initialize any datasource.");
    }

    private DataSource createDataSource(DataSourceProperties properties) {
        HikariDataSource dataSource = properties.initializeDataSourceBuilder()
                .type(HikariDataSource.class)
                .build();
        this.delegate = dataSource;
        return dataSource;
    }

    private boolean isDataSourceHealthy(DataSource dataSource) {
        if (dataSource == null) {
            return false;
        }

        try (Connection connection = dataSource.getConnection()) {
            return connection.isValid(2);
        } catch (SQLException ex) {
            logger.warn("Datasource health check failed: {}", ex.getMessage());
            closeQuietly(dataSource);
            return false;
        }
    }

    private void closeQuietly(DataSource dataSource) {
        if (dataSource instanceof HikariDataSource hikari) {
            try {
                hikari.close();
            } catch (Exception ignored) {
                // ignore
            }
        }
    }

    private DataSourceProperties createH2Properties() {
        DataSourceProperties properties = new DataSourceProperties();
        properties.setUrl("jdbc:h2:mem:ascbdb;DB_CLOSE_DELAY=-1;DB_CLOSE_ON_EXIT=FALSE");
        properties.setUsername("sa");
        properties.setPassword("");
        properties.setDriverClassName("org.h2.Driver");
        return properties;
    }

    @PreDestroy
    public void shutdown() {
        if (delegate != null) {
            delegate.close();
        }
    }
}
