package ro.ascb.ascb_db_backend.controller;

import org.springframework.core.env.Environment;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import ro.ascb.ascb_db_backend.repository.VoluntarRepository;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/debug")
public class DebugController {

    private final Environment env;
    private final VoluntarRepository voluntarRepository;

    public DebugController(Environment env, VoluntarRepository voluntarRepository) {
        this.env = env;
        this.voluntarRepository = voluntarRepository;
    }

    @GetMapping("/info")
    public Map<String, Object> info() {
        Map<String, Object> m = new HashMap<>();
        String url = env.getProperty("spring.datasource.url");
        m.put("datasourceUrl", url == null ? "(none)" : url);
        try {
            long cnt = voluntarRepository.count();
            m.put("voluntariCount", cnt);
        } catch (Exception ex) {
            m.put("voluntariCountError", ex.getMessage());
        }
        return m;
    }

    @GetMapping("/health")
    public Map<String, String> health() {
        Map<String, String> response = new HashMap<>();
        response.put("status", "UP");
        return response;
    }

    @PostMapping("/shutdown")
    public Map<String, String> shutdown() {
        Map<String, String> response = new HashMap<>();
        response.put("message", "Server shutdown initiated");
        
        // Shutdown the server after a short delay
        new Thread(() -> {
            try {
                Thread.sleep(1000); // Wait 1 second
                System.exit(0);
            } catch (InterruptedException e) {
                System.exit(1);
            }
        }).start();
        
        return response;
    }
}
