package ro.ascb.frontend;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.Duration;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class MainApp extends Application {

    private static final String BACKEND_URL = "http://localhost:8080";
    private final HttpClient httpClient = HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(5))
            .build();

    @Override
    public void start(Stage primaryStage) throws Exception {
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/fxml/Login.fxml"));
        Scene scene = new Scene(fxmlLoader.load());
        primaryStage.setTitle("ASCB - Login");
        primaryStage.setScene(scene);
        
        // Add shutdown handler when window is closed
        primaryStage.setOnCloseRequest(event -> {
            shutdownBackend();
        });
        
        // Signal when GUI is ready so batch script can close CMD windows
        primaryStage.setOnShown(event -> {
            signalGuiReady();
        });
        
        primaryStage.show();
    }
    
    private void signalGuiReady() {
        try {
            // Write a marker file to temp directory to signal that GUI is ready
            String markerPath = System.getProperty("java.io.tmpdir") + "ascb_gui_ready.txt";
            Files.write(Paths.get(markerPath), "GUI Ready".getBytes());
            System.out.println("GUI ready signal written to: " + markerPath);
        } catch (Exception e) {
            System.err.println("Error writing GUI ready signal: " + e.getMessage());
        }
    }

    private void shutdownBackend() {
        try {
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(BACKEND_URL + "/api/debug/shutdown"))
                    .POST(HttpRequest.BodyPublishers.noBody())
                    .build();
            
            // Send shutdown request asynchronously
            httpClient.sendAsync(request, HttpResponse.BodyHandlers.ofString())
                    .thenAccept(response -> {
                        System.out.println("Backend shutdown initiated: " + response.body());
                    })
                    .exceptionally(throwable -> {
                        System.err.println("Failed to shutdown backend: " + throwable.getMessage());
                        return null;
                    });
            
            // Give some time for the request to be sent
            Thread.sleep(500);
            
        } catch (Exception e) {
            System.err.println("Error shutting down backend: " + e.getMessage());
        }
    }

    public static void main(String[] args) {
        launch(args);
    }
}
